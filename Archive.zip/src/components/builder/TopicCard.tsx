/**
 * Draggable topic card component
 */

"use client";

import { Plus, Check } from "lucide-react";
import { Topic } from "@/types/core";
import { cn } from "@/lib/utils";

interface TopicCardProps {
  topic: Topic;
  onAdd: () => void;
  isSelected?: boolean;
}

export function TopicCard({ topic, onAdd, isSelected = false }: TopicCardProps) {
  return (
    <div
      className={cn(
        "flex items-center justify-between w-full rounded-organic-md px-3.5 py-3.5 text-white/90 transition-all",
        isSelected 
          ? "bg-primary/10" 
          : "bg-white/[0.08] hover:bg-white/[0.12]"
      )}
    >
      {/* Label + description */}
      <div className="flex items-center gap-3 flex-1 min-w-0">
        <div className="flex flex-col gap-0.5 flex-1 min-w-0">
          <span className="truncate text-base font-semibold">{topic.name}</span>
          <span className="truncate text-xs text-white/40">{topic.description}</span>
        </div>
      </div>

      {/* Add button */}
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onAdd();
        }}
        disabled={isSelected}
        className={cn(
          "h-8 w-8 inline-flex items-center justify-center rounded-organic-md flex-shrink-0 transition-all",
          isSelected
            ? "bg-primary/20 text-primary cursor-default"
            : "bg-white/5 text-white/70 hover:bg-white/10 interaction-scale"
        )}
        aria-label={`Add ${topic.name}`}
        title={isSelected ? "Already added" : "Add to session"}
      >
        {isSelected ? <Check size={16} strokeWidth={2.5} /> : <Plus size={18} strokeWidth={2} />}
      </button>
    </div>
  );
}



