Update the Quality Gate diagram backfill system to support generated image backfill using the best available image model.

Context:
This is the Quality Gate “Graph add” path for existing DB questions. It is not V4 generation-time visuals and it is not the review-app concept PNG regeneration button.

Current system:
- Quality gate scores stored questions.
- graph_enrichment marks rows as candidate/missing_expected.
- Existing SVG path can generate inline <svg> and merge it into question_stem.
- We now want an image-generation path that creates a monochrome exam-style PNG/WebP diagram, verifies it with a vision model, uploads it, then merges it into question_stem as an <img> inside <figure class="qg-diagram">.

Important:
Keep the existing SVG path. Add image backfill as an additional mode.

==================================================
MODEL CONFIG
==================================================

Add these env vars:

MODEL_QUALITY_GATE_IMAGE=imagen-4.0-ultra-generate-001
MODEL_QUALITY_GATE_IMAGE_FALLBACK=imagen-4.0-generate-001
MODEL_QUALITY_GATE_IMAGE_FAST=imagen-4.0-fast-generate-001
MODEL_QUALITY_GATE_IMAGE_BRIEF=gemini-2.5-pro
MODEL_QUALITY_GATE_IMAGE_VERIFY=gemini-2.5-pro
MODEL_QUALITY_GATE_IMAGE_INTEGRATE=gemini-2.5-pro

Use:
- Gemini 2.5 Pro for deciding what is missing and building the brief.
- Imagen 4 Ultra for production image generation.
- Gemini 2.5 Pro vision for verification.
- Gemini 2.5 Pro or Flash for integration; default to Pro first.

Do not hard-code model IDs. Read from env vars.

==================================================
NEW PROMPT FILES
==================================================

Create:

quality_gate/prompt_image_brief.md
quality_gate/prompt_image_generate.md
quality_gate/prompt_image_verify.md
quality_gate/prompt_image_retry.md
quality_gate/prompt_image_integrate.md

Use the exact prompt contents from the attached zip.

==================================================
PIPELINE
==================================================

Add an image backfill pipeline, likely in a new file:

quality_gate/image_diagram.py

Main function idea:

run_auto_image_diagram_for_row(row, *, image_model, brief_model, verify_model, integrate_model, dry_run=False, max_retries=1, allow_high_precision_image=False, replace_existing_diagram=False)

Pipeline steps:

1. Build image brief
Input:
- question_stem
- quality_gate_payload.graph_enrichment
- quality_gate_graph_notes
- subject/difficulty if available
- existing diagram status

Call prompt_image_brief.md using MODEL_QUALITY_GATE_IMAGE_BRIEF.

Output JSON:
{
  should_generate,
  diagram_need,
  spoiler_risk,
  precision_risk,
  reason_to_generate,
  image_brief,
  required_elements,
  optional_elements,
  forbidden_elements,
  labels_required,
  measurements_required,
  insertion_hint,
  aspect_ratio,
  alt_text,
  notes
}

2. Skip unsafe/unsuitable items
Skip and log if:
- should_generate=false
- spoiler_risk=high
- precision_risk=high and --allow-high-precision-image is not passed
- stem already contains <figure class="qg-diagram">, <svg>, or <img> and --replace-existing-diagram is not passed

Reason:
Generated images are not reliable for exact graphs, exact coordinate geometry, exact intersections, or anything that could reveal the answer by inspection.

3. Generate image
Use MODEL_QUALITY_GATE_IMAGE, default:
imagen-4.0-ultra-generate-001

Use prompt_image_generate.md.

Default aspect ratio: 4:3 unless image brief says otherwise.

Output format:
PNG or WebP.

The image prompt must strongly enforce:
- monochrome
- white background
- thin black/grey linework
- light grey fills only if needed
- no colour
- no gradients
- no shadows
- no glow
- no textures
- no photorealism
- no cartoon style
- no decorative border
- no watermark
- no title
- no caption
- sparse readable labels
- exam-paper style
- no answer-revealing labels
- no invented measurements
- no answer options

4. Verify image
Use MODEL_QUALITY_GATE_IMAGE_VERIFY with vision input.

Use prompt_image_verify.md.

Verifier returns:
{
  verdict: pass/minor_fix/fail,
  can_merge,
  style_score,
  math_score,
  label_score,
  spoiler_score,
  issues,
  missing_required_elements,
  incorrect_elements,
  invented_elements,
  unsafe_spoilers,
  retry_prompt
}

Only merge if can_merge=true and verdict="pass".

5. Retry once
If verification does not pass:
- regenerate using prompt_image_retry.md
- verify again
- if still not pass, do not merge
- log failed

Default max retries: 1.

6. Upload image
Upload final verified image to Supabase Storage.

Create/use bucket:
quality-gate-diagrams

Recommended path:
quality-gate-diagrams/{question_id}/{timestamp_or_hash}.webp

Store URL in DB if possible:
- quality_gate_diagram_image_url
- quality_gate_diagram_image_model
- quality_gate_diagram_image_verified_at
- quality_gate_diagram_image_payload

If avoiding migrations initially:
- include URL in merged question_stem
- log URL in image_backfill_history.jsonl

7. Merge image into stem
Use prompt_image_integrate.md.

Insert:

<figure class="qg-diagram" style="margin:1em 0;text-align:center;">
  <img src="..." alt="..." style="max-width:100%;height:auto;" />
</figure>

Rules:
- preserve existing HTML and KaTeX
- preserve option text
- do not add excessive line breaks
- do not reflow the whole stem
- do not duplicate existing diagrams
- place image where it supports the setup best
- if a placeholder exists, replace it

8. Update DB
Patch:
- question_stem = merged HTML
- question_stem_before_auto_diagram = previous stem if not already set
- optional image metadata columns if added

9. Audit logging
Write to:
quality_gate/image_backfill_history.jsonl

For every row log:
- question id
- graph mode
- should_generate
- diagram_need
- spoiler_risk
- precision_risk
- image model
- brief model
- verifier model
- verification verdict
- verification issues
- retry attempted
- uploaded URL
- final status: merged/skipped/failed
- reason

==================================================
CLI UPDATES
==================================================

Add command or flags:

python quality_gate/cli.py generate-missing-images --limit 20 --operator-queue-only

Also support:
--image-backfill
--diagram-mode image|svg|auto
--diagram-dry-run
--operator-queue-only
--limit
--max-image-retries 1
--allow-high-precision-image
--replace-existing-diagram
--image-model
--image-brief-model
--image-verify-model

Recommended auto logic:
- exact function graph / coordinate graph / precise geometry → SVG only
- physical schematic / force diagram / container / qualitative setup → image allowed
- high spoiler risk → skip
- existing diagram present → skip unless replace flag

==================================================
STREAMLIT UI UPDATES
==================================================

In the backfill UI, add image mode controls:
- mode: svg / image / auto
- dry run checkbox
- allow high precision image checkbox, default false
- max retries
- model selectors/overrides if easy

In the backfill table show:
- graph notes
- generated image brief
- diagram_need
- spoiler risk
- precision risk
- verification verdict
- verification issues
- generated image preview
- before/after stem preview
- queue/skip controls

==================================================
REVIEW APP
==================================================

Check:
review-app/src/components/shared/StemContent.tsx

Ensure it renders:
<figure class="qg-diagram"><img ... /></figure>

Ensure image max-width is sensible and does not appear huge.

==================================================
SAFETY / QUALITY RULES
==================================================

The generated image must help interpret the setup, not solve the question.

Skip rather than generate if:
- the image would reveal the answer
- the image would need exact plotting
- the image would need exact scale
- the image would need exact intersections
- the stem is too ambiguous to draw safely
- the current graph notes are vague
- there is already a good diagram

Do not use generated images for:
- exact function graphs
- exact coordinate geometry
- root/intersection counting
- option-matching visual answers
- target unknowns that could be read from the image

Use generated images for:
- physical setup diagrams
- force/direction diagrams
- containers/layers
- simple apparatus
- simple ray/mirror setups
- qualitative geometry/spatial sketches
- diagrams where the answer still requires reasoning

==================================================
FILES TO INSPECT
==================================================

quality_gate/svg_diagram.py
quality_gate/svg_backfill.py
quality_gate/runner.py
quality_gate/supabase_io.py
quality_gate/streamlit_app.py
quality_gate/cli.py
quality_gate/prompt.md
quality_gate/prompt_svg_integrate.md
review-app/src/components/shared/StemContent.tsx
pipeline_v4/stem_splice.py
diagram_regen_worker.py

Use existing upload/storage/client patterns where possible.

==================================================
ACCEPTANCE CRITERIA
==================================================

A queued graph candidate can be processed with:

python quality_gate/cli.py generate-missing-images --limit 1 --operator-queue-only --diagram-dry-run

Dry run should:
- create image brief
- skip unsafe cases
- generate image only if safe
- verify image
- show/log verdict
- not update DB

Real run should:
- generate image
- verify it
- upload it
- merge <img> into question_stem
- backup previous stem
- audit log everything

The old SVG path must still work.
